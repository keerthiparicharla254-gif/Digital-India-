function go(file){window.location.href=file;}
document.querySelectorAll('.nav').forEach(n=>{if(n.innerText.includes(document.title.split('|')[0].trim()))n.classList.add('active')});
const form=document.getElementById('requestForm');
if(form)form.addEventListener('submit',e=>{e.preventDefault();document.getElementById('formMessage').textContent='✅ Your service request was submitted successfully (demo).';form.reset();});
const cf=document.getElementById('contactForm');
if(cf)cf.addEventListener('submit',e=>{e.preventDefault();alert('Thank you! Your message was submitted (demo).');cf.reset();});
const search=document.getElementById('search');
if(search)search.addEventListener('input',e=>{const q=e.target.value.toLowerCase();document.querySelectorAll('.card,.service-item').forEach(x=>x.style.display=(!q||x.innerText.toLowerCase().includes(q))?'':'none');});
